<?php

//this file is responsible for user related information in the server

if (empty($_REQUEST['id']) || empty($_REQUEST['email']) || empty($_REQUEST['firstName']) || empty($_REQUEST['lastName']) || empty($_REQUEST['birthday']) || empty($_REQUEST['gender'])) {
     $return['status'] = '400';
    $return['message'] = 'Missing required information.';
    echo json_encode($return);
    return;           
}

$id = htmlentities($_REQUEST['id']);
$email = htmlentities($_REQUEST['email']);
$firstName = htmlentities($_REQUEST['firstName']);
$lastName = htmlentities($_REQUEST['lastName']);
$birthday = htmlentities($_REQUEST['birthday']);
$gender = htmlentities($_REQUEST['gender']);


require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

$result = $access->updateUser($email, $firstName, $lastName, $birthday, $gender, $id);

if ($result){
     $return['status'] = '200';
     $return['message'] = 'Profile has been updated successfully.';
     
     if ($_REQUEST['newPassword'] == 'true') {
         $password = htmlentities($_REQUEST['password']);
         $salt = openssl_random_pseudo_bytes(20);
         $dbpassword = sha1($password . $salt);
         
         $passwordChangedStmt = $access->updatePassword($id, $dbpassword, $salt);
       
         if ($passwordChangedStmt) {
             $return['password'] = 'Password changed successfully.';
         } else {
             $return['password'] = 'Password could not be changed.';
         }
     }
     
     // select currently inserted user
        $user = $access->selectUserID($id);
        
        if ($user) {
        // throw back the user details
        $return['id'] = $user['id'];
        $return['email'] = $user['email'];
//        $return['password'] = $user['password'];
        $return['firstName'] = $user['firstName'];
        $return['lastName'] = $user['lastName'];
        $return['birthday'] = $user['birthday'];
        $return['gender'] = $user['gender'];
        $return['cover'] = $user['cover'];
        $return['avatar'] = $user['avatar'];
        $return['bio'] = $user['bio'];
        } else {
            $return['status'] = '400';
        $return['message'] = 'Could not complete the process.';
        }
} else {
        $return['status'] = '400';
        $return['message'] = 'Could not update user.';
}
echo json_encode($return);
$access->disconnect();
