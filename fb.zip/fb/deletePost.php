<?php

require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();


if (empty($_REQUEST['id'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information';
      $return['deleted'] = false;
    $access->disconnect();
    echo json_encode($return);
    return;
}

$id = html_entity_decode($_REQUEST['id']);


$result = $access->deletePost($id);

if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Post deleted successfully.';
    $return['deleted'] = $result;
} else {
    $return['status'] = '400';
    $return['message'] = 'Error in deleting post';
    $return['deleted'] = $result;
}

$access->disconnect();
echo json_encode($return);
