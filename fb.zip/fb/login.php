<?php

if (empty($_REQUEST['email']) || empty($_REQUEST['password'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information';
    return;
}

$email = html_entity_decode($_REQUEST['email']);
$password = html_entity_decode($_REQUEST['password']);

require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

$user = $access->selectUser($email);

if ($user) {
    
    $encryptedPassword = $user['password'];
    $salt = $user['salt'];
            
    if ($encryptedPassword == sha1($password . $salt)) {
        $return['status'] = '200';
        $return['message'] = 'Logged in uccessfully';
        $return['email'] = $user['email'];
        $return['password'] = $user['password'];
        $return['firstName'] = $user['firstName'];
        $return['lastName'] = $user['lastName'];
        $return['birthday'] = $user['birthday'];
        $return['gender'] = $user['gender'];
        $return['id'] = $user['id'];
        $return['cover'] = $user['cover'];
        $return['avatar'] = $user['avatar'];
        $return['bio'] = $user['bio'];
        $return['allow_friends'] = $user['allow_friends'];
        $return['allow_follow'] = $user['allow_follow'];
    } else {
    $return['status'] = '201';
    $return['message'] = 'Password do not match';
    
}
} else {
    $return['status'] = '401';
    $return['message'] = 'User is not found';
    
}
$access->disconnect();
echo json_encode($return);
