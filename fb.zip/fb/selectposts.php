<?php

if (!isset($_REQUEST['id']) && !isset($_REQUEST['limit']) && !isset($_REQUEST['offset'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information.';
    echo json_encode($return);
    return;
}

$id = htmlentities($_REQUEST['id']);
$limit = htmlentities($_REQUEST['limit']);
$offset = htmlentities($_REQUEST['offset']);

require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

$posts = $access->selectPosts($id, $offset, $limit);

if ($posts) {
    
    $return['posts'] = $posts;
    echo json_encode($return);
}

$access->disconnect();
