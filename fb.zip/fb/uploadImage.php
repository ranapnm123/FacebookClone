<?php

if (empty($_REQUEST['id']) && empty($_REQUEST['type'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information';
    echo json_encode($return);
    return;
}

$id = htmlentities($_REQUEST['id']);
$type = htmlentities($_REQUEST['type']);

require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

if (isset($_FILES['file']) && $_FILES['file']['size'] > 1) {
    
    $folder = '/Applications/XAMPP/xamppfiles/htdocs/fb/' . $type . '/' . $id;
   
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    } else {
        $return['folder_message'] = 'Could not create a folder.';
    }
    
    $filePath = $folder . '/' . basename($_FILES['file']['name']);
    
    
    
    if (move_uploaded_file($_FILES['file']['tmp_name'], $filePath)) {
        $fileUrl = 'http://localhost/fb/' . $type . '/' . $id . '/' . $_FILES['file']['name'];
        
        $access->updateImageUrl($type, $fileUrl, $id);
    
        
       
        
    } else {
        $return['status'] = '400';
        $return['message'] = 'Could not upload file';
        
    }
    
} else {
    $fileUrl = '';
    $files = glob('/Applications/XAMPP/xamppfiles/htdocs/fb/' . $type . '/' . $id . '/*');
    foreach ($files as $file) {
        if (is_file($file))
            unlink ($file);
        
        $access->updateImageUrl($type, $fileUrl, $id);
    }
    
   
    
}

 
        // select currently inserted user
        $user = $access->selectUserID($id);
        if ($user) {
        // throw back the user details
        $return['status'] = '200';
        $return['message'] = 'File has been uploaded successfully';
        $return['' . $type . ''] = $fileUrl;
        $return['id'] = $user['id'];
        $return['email'] = $user['email'];
        $return['password'] = $user['password'];
        $return['firstName'] = $user['firstName'];
        $return['lastName'] = $user['lastName'];
        $return['birthday'] = $user['birthday'];
        $return['gender'] = $user['gender'];
        $return['cover'] = $user['cover'];
        $return['avatar'] = $user['avatar'];
        $return['bio'] = $user['bio'];
        } else {
            $return['status'] = '400';
        $return['message'] = 'Could not process.';
        }
    $access->disconnect();
   echo json_encode($return);


