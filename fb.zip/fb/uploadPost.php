<?php

if (empty($_REQUEST['user_id']) || empty($_REQUEST['text'])) {
        $return['status'] = '400';
        $return['message'] = 'Missing required information.';
        echo json_encode($return);
        return;  
}

$user_id = htmlentities($_REQUEST['user_id']);
$text = htmlentities($_REQUEST['text']);
$pic = '';

require 'secure/access.php';
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

if (isset($_FILES['file']) || $_FILES['file']['size'] > 1) {
    
    $folder = '/Applications/XAMPP/xamppfiles/htdocs/fb/posts/' . $user_id;
    
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    } else {
        $return['folder_message'] = 'Could not create a directory.';
    }
    
    $path = $folder . '/' . basename($_FILES['file']['name']);
    
    if (move_uploaded_file($_FILES['file']['tmp_name'], $path)) {
        
        $pic = 'http://localhost/fb/posts/' . $user_id . '/' . $_FILES['file']['name'];
        $return['picture'] = $pic;
        
    } else {
        $return['folder_message'] = 'Could not uploaded file.';
    }
}

$result = $access->insertPost($user_id, $text, $pic);

if ($result) {
        $return['status'] = '200';
        $return['message'] = 'Post published successfully.';
} else {
        $return['status'] = '400';
        $return['message'] = 'Error in publishing post.';
}
$access->disconnect();
echo json_encode($return);
        