<?php






require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

$return = array();
        
if ($_REQUEST['action'] == 'insert') {
    
    if (empty($_REQUEST['post_id']) || empty($_REQUEST['user_id']) || empty($_REQUEST['comment'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for insert.';
    echo json_encode($return);
    $access->disconnect();
    return;
    }
    
    $post_id = htmlentities($_REQUEST['post_id']);
    $user_id = htmlentities($_REQUEST['user_id']);    
    $comment = htmlentities($_REQUEST['comment']);
    
    $result = $access->insertComment($post_id, $user_id, $comment); 
    
    if ($result) {
        $return['status'] = '200';
        $return['message'] = 'Comment posted successfully.';
        $return['new_comment_id'] = mysqli_insert_id($access->conn);
    } else {
        $return['status'] = '400';
        $return['message'] = 'Could not post comment.';
    }
} else if ($_REQUEST['action'] == 'select') {
    
     if (empty($_REQUEST['post_id']) || empty($_REQUEST['limit']) || !isset($_REQUEST['offset'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for select.';
    echo json_encode($return);
    $access->disconnect();
    return;
    }
    
    $post_id = htmlentities($_REQUEST['post_id']);
    $limit = htmlentities($_REQUEST['limit']);
    $offset = htmlentities($_REQUEST['offset']);
    
    
    $comments = $access->selectComments($post_id, $offset, $limit);
    
    if ($comments) {
        $return['comments'] = $comments;
    } else {
        
    }
} else if ($_REQUEST['action'] == 'delete') {
    
    if (empty($_REQUEST['id'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for selete.';
    echo json_encode($return);
    $access->disconnect();
    return;
    }
    
    $id = htmlentities($_REQUEST['id']);
    
    $deleted = $access->deleteComment($id);
    
    if ($deleted) {
        $return['status'] = '200';
        $return['message'] = 'Deleted successfully.';
    } else {
        $return['status'] = '400';
        $return['message'] = 'Errror in deleting comment.';
    }
    
}
$access->disconnect();
echo json_encode($return);


