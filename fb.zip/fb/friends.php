<?php

require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

if ($_REQUEST['action'] == 'search') {
if (!isset($_REQUEST['id']) || !isset($_REQUEST['name']) || !isset($_REQUEST['limit']) || !isset($_REQUEST['offset'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for search.';
    echo json_encode($return);
    $access->disconnect();
    return;
}

$name = htmlentities($_REQUEST['name']);
$id = htmlentities($_REQUEST['id']);
$offset = htmlentities($_REQUEST['offset']);
$limit = htmlentities($_REQUEST['limit']);

$users = $access->selectUsers($name, $id, $limit, $offset);

if ($users) {
    $return['status'] = '200';
    $return['users'] = $users;
} else {
    $return['status'] = '400';
    $return['message'] = 'No user found.';
}
} else if ($_REQUEST['action'] == 'add') {
if (!isset($_REQUEST['user_id']) || !isset($_REQUEST['friend_id']) ) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for add.';
    echo json_encode($return);
    $access->disconnect();
    return;
}
$user_id = htmlentities($_REQUEST['user_id']);
$friend_id = htmlentities($_REQUEST['friend_id']);
$result = $access->insertRequest($user_id, $friend_id);
 if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Friend request sent successfully.';
 } else {
     $return['status'] = '400';
    $return['message'] = 'Could not send request.';
 }
} else if ($_REQUEST['action'] == 'reject') {
if (!isset($_REQUEST['user_id']) || !isset($_REQUEST['friend_id']) ) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for reject.';
    echo json_encode($return);
    $access->disconnect();
    return;
}
$user_id = htmlentities($_REQUEST['user_id']);
$friend_id = htmlentities($_REQUEST['friend_id']);
$result = $access->deleteRequest($user_id, $friend_id);
 if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Friend request rejected successfully.';
 } else {
     $return['status'] = '400';
     $return['message'] = 'Could not reject request.';
 }
} else if (($_REQUEST['action']) == 'requests') {
    if (!isset($_REQUEST['id']) || !isset($_REQUEST['limit']) || !isset($_REQUEST['offset'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for requests.';
    echo json_encode($return);
    $access->disconnect();
    return;
}

$id = htmlentities($_REQUEST['id']);
$offset = htmlentities($_REQUEST['offset']);
$limit = htmlentities($_REQUEST['limit']);

$result = $access->selectRequests($id, $limit, $offset);

if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Friend request rejected successfully.';
    $return['requests'] = $result;
} else {
    $return['status'] = '400';
     $return['message'] = 'Could not select requests.';
}

} else if (($_REQUEST['action']) == 'confirm') {
    if (!isset($_REQUEST['user_id']) || !isset($_REQUEST['friend_id'])) {
        $return['status'] = '400';
    $return['message'] = 'Missing required information for requests.';
    echo json_encode($return);
    $access->disconnect();
    return;
    }
        $user_id = htmlentities($_REQUEST['user_id']);
        $friend_id = htmlentities($_REQUEST['friend_id']);
    
    $result = $access->insertFriend($user_id, $friend_id);
    if ($result) {
      
        $access->deleteRequest($user_id, $friend_id );
        $return['status'] = '200';
        $return['message'] = 'Friend is confirmed successfully.';
} else {
        $return['status'] = '400';
        $return['message'] = 'Failed to confirm friend.';
}
} else if (($_REQUEST['action']) == 'delete') {
    
    if (!isset($_REQUEST['user_id']) || !isset($_REQUEST['friend_id'])) {
        $return['status'] = '400';
    $return['message'] = 'Missing required information for requests.';
    echo json_encode($return);
    $access->disconnect();
    return;
    }
        $user_id = htmlentities($_REQUEST['user_id']);
        $friend_id = htmlentities($_REQUEST['friend_id']);
    
        $result = $access->deleteFriend($user_id, $friend_id);
        
        if ($result) {
      
        $return['status'] = '200';
        $return['message'] = 'Friend is removed successfully.';
        } else {
        $return['status'] = '400';
        $return['message'] = 'Failed to remove friend.';
        }
} else if (($_REQUEST['action']) == 'follow') {
    if (!isset($_REQUEST['user_id']) || !isset($_REQUEST['follow_id']) ) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for follow.';
    echo json_encode($return);
    $access->disconnect();
    return;
}
$user_id = htmlentities($_REQUEST['user_id']);
$follow_id = htmlentities($_REQUEST['follow_id']);
$result = $access->insertFollow($user_id, $follow_id);
 if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Started following successfully.';
 } else {
     $return['status'] = '400';
    $return['message'] = 'Could not send request.';
 }
} else if ($_REQUEST['action'] == 'unfollow') {
if (!isset($_REQUEST['user_id']) || !isset($_REQUEST['follow_id']) ) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for unfollow.';
    echo json_encode($return);
    $access->disconnect();
    return;
}
$user_id = htmlentities($_REQUEST['user_id']);
$follow_id = htmlentities($_REQUEST['follow_id']);
$result = $access->deleteFollow($user_id, $follow_id);
 if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Unfollowing successfully.';
 } else {
     $return['status'] = '400';
     $return['message'] = 'Could not unfollow request.';
 }
} 
else if ($_REQUEST['action'] == "recommended") {
    if (!isset($_REQUEST['id']) || !isset($_REQUEST['limit']) || !isset($_REQUEST['offset'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information.';
    echo json_encode($return);
    $access->disconnect();
    return;
}
$id = htmlentities($_REQUEST['id']);
$offset = htmlentities($_REQUEST['offset']);
$limit = htmlentities($_REQUEST['limit']);

$users = $access->selectRecommendedFriends($id, $limit, $offset);

if ($users) {
    $return['status'] = '200';
    $return['message'] = 'Friend request rejected successfully.';
    $return['users'] = $users;
} else {
    $return['status'] = '400';
    $return['message'] = 'No recommended friend found.';
}

}
else if ($_REQUEST['action'] == "friends") {
    if (!isset($_REQUEST['id']) || !isset($_REQUEST['limit']) || !isset($_REQUEST['offset'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information.';
    echo json_encode($return);
    $access->disconnect();
    return;
}
$id = htmlentities($_REQUEST['id']);
$offset = htmlentities($_REQUEST['offset']);
$limit = htmlentities($_REQUEST['limit']);

$users = $access->selectFriends($id, $limit, $offset);

if ($users) {
    $return['status'] = '200';
    $return['message'] = 'Friends selected successfully.';
    $return['friends'] = $users;
} else {
    $return['status'] = '400';
    $return['message'] = 'No friends found.';
}

} 



    echo json_encode($return);
    $access->disconnect();
