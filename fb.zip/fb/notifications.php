<?php

require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

if (!isset($_REQUEST['byUser_id']) || !isset($_REQUEST['user_id']) || !isset($_REQUEST['type']) ) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information for search.';
    echo json_encode($return);
    $access->disconnect();
    return;
}

$byUser_id = htmlentities($_REQUEST['byUser_id']);
$user_id = htmlentities($_REQUEST['user_id']);
$type = htmlentities($_REQUEST['type']);


if ($_REQUEST['action'] == 'insert') {
    $result = $access->insertNotification($byUser_id, $user_id, $type);
    if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Notification inserted successfully.';
 } else {
     $return['status'] = '400';
    $return['message'] = 'Could not inserted notification.';
 }
} else if ($_REQUEST['action'] == 'delete') {
    $result = $access->deleteNotification($byUser_id, $user_id, $type);
    if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Notification deleted successfully.';
     } else {
         $return['status'] = '400';
        $return['message'] = 'Could not delete notification.';
     }
} else if ($_REQUEST['action'] == 'select') {
    if (!isset($_REQUEST['limit']) || !isset($_REQUEST['offset']) ) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information.';
    echo json_encode($return);
    $access->disconnect();
    return;
    }
    
    $limit = htmlentities($_REQUEST['limit']);
    $offset = htmlentities($_REQUEST['offset']);

    $result = $access->selectNotifications($user_id, $limit, $offset);
    if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Notification selected successfully.';
    $return['notifications'] = $result;
    
     } else {
         $return['status'] = '400';
        $return['message'] = 'Could not select notification.';
     }
} else if ($_REQUEST['action'] == 'update') {
    if (!isset($_REQUEST['id']) ) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information.';
    echo json_encode($return);
    $access->disconnect();
    return;
    }
    
    $id = htmlentities($_REQUEST['id']);
    $viewed = htmlentities($_REQUEST['viewed']);

    $result = $access->updateNotification($id, $viewed);
    if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Notification updated successfully.';
    
     } else {
         $return['status'] = '400';
        $return['message'] = 'Could not update notification.';
     }
    }

echo json_encode($return);
$access->disconnect();