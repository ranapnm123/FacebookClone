<?php

require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

if (!isset($_REQUEST['byUser_id']) || !isset($_REQUEST['post_id']) || !isset($_REQUEST['user_id']) || !isset($_REQUEST['reason'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information.';
    echo json_encode($return);
    $access->disconnect();
    return;
}

$byUser_id = html_entity_decode($_REQUEST['byUser_id']);
$post_id = html_entity_decode($_REQUEST['post_id']);
$user_id = html_entity_decode($_REQUEST['user_id']);
$reason = html_entity_decode($_REQUEST['reason']);

$result = $access->insertReport($post_id, $user_id, $reason, $byUser_id);

if ($result) {
    $return['status'] = '200';
    $return['message'] = 'Reported successfully.';
} else {
    $return['status'] = '400';
    $return['message'] = 'Could not report';
}

echo json_encode($return);
$access->disconnect();