<?php

//responsible for like and dislike

if (empty($_REQUEST['post_id']) || empty($_REQUEST['user_id'])) {
    $return['status'] = '400';
    $return['message'] = 'Missing required information';
    echo json_encode($return);
    return;
}

$post_id = htmlentities($_REQUEST['post_id']);
$user_id = htmlentities($_REQUEST['user_id']);

require('secure/access.php');
$access = new access('localhost', 'root', '', 'fb');
$access->connect();

if ($_REQUEST['action'] == 'insert') {
   $result = $access->insertLike($post_id, $user_id);
    
    if ($result) {
        $return['status'] = '200';
        $return['message'] = 'Like has been registered successfully.';
    } else {
        $return['status'] = '400';
        $return['message'] = 'Could not register like.';
    }
} else {
    $result = $access->deleteLike($post_id, $user_id);
    
    if ($result) {
        $return['status'] = '200';
        $return['message'] = 'Like has been removed successfully.';
    } else {
        $return['status'] = '400';
        $return['message'] = 'Could not remove the like.';
    }
}

$access->disconnect();
echo json_encode($return);
